package com.towseef.whereislipped;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO = 1001;
    private static final int REQ_FILE = 1002;
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private android.media.MediaRecorder recorder;
    private File voiceFile;
    private long recordingStartedAt;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        setContentView(webView);
        configureWebView();
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                if ("file".equals(u.getScheme())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    String[] resources = request.getResources();
                    boolean audio = false;
                    for (String r : resources) if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) audio = true;
                    if (audio && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
                    } else {
                        request.grant(resources);
                    }
                });
            }

            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                try {
                    Intent intent = params.createIntent();
                    startActivityForResult(intent, REQ_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    cb.onReceiveValue(null);
                }
                return true;
            }
        });

        webView.addJavascriptInterface(new NativeVoice(), "AndroidVoice");
    }

    public class NativeVoice {
        @JavascriptInterface public void startRecording() {
            runOnUiThread(() -> {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
                    webView.evaluateJavascript("window.__nativeVoiceError && window.__nativeVoiceError('Microphone permission is required. Tap Record again after allowing it.');", null);
                    return;
                }
                if (recorder != null) return;
                try {
                    File dir = getExternalFilesDir(Environment.DIRECTORY_MUSIC);
                    if (dir == null) dir = getFilesDir();
                    voiceFile = new File(dir, "voice_" + System.currentTimeMillis() + ".m4a");
                    recorder = new android.media.MediaRecorder();
                    recorder.setAudioSource(android.media.MediaRecorder.AudioSource.MIC);
                    recorder.setOutputFormat(android.media.MediaRecorder.OutputFormat.MPEG_4);
                    recorder.setAudioEncoder(android.media.MediaRecorder.AudioEncoder.AAC);
                    recorder.setAudioEncodingBitRate(64000);
                    recorder.setAudioSamplingRate(44100);
                    recorder.setOutputFile(voiceFile.getAbsolutePath());
                    recorder.prepare();
                    recorder.start();
                    recordingStartedAt = System.currentTimeMillis();
                    webView.evaluateJavascript("window.__nativeVoiceRecordingStarted && window.__nativeVoiceRecordingStarted();", null);
                } catch (Exception e) {
                    cleanupRecorder();
                    sendVoiceError("Could not start recording: " + safe(e.getMessage()));
                }
            });
        }

        @JavascriptInterface public void stopRecording() {
            runOnUiThread(() -> {
                if (recorder == null) return;
                try {
                    recorder.stop();
                    recorder.release();
                    recorder = null;
                    long seconds = Math.max(1, TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis() - recordingStartedAt));
                    byte[] bytes = readAll(voiceFile);
                    String b64 = Base64.encodeToString(bytes, Base64.NO_WRAP);
                    String js = "window.__nativeVoiceReady && window.__nativeVoiceReady('" + b64 + "','audio/mp4'," + seconds + ");";
                    webView.evaluateJavascript(js, null);
                } catch (Exception e) {
                    cleanupRecorder();
                    sendVoiceError("Recording could not be saved.");
                }
            });
        }
    }

    private byte[] readAll(File f) throws IOException {
        FileInputStream in = new FileInputStream(f);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
        in.close();
        return out.toByteArray();
    }

    private String safe(String s) { return s == null ? "unknown error" : s.replace("'", "\\'"); }
    private void sendVoiceError(String msg) {
        webView.evaluateJavascript("window.__nativeVoiceError && window.__nativeVoiceError('" + safe(msg) + "');", null);
    }
    private void cleanupRecorder() {
        try { if (recorder != null) recorder.release(); } catch (Exception ignored) {}
        recorder = null;
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE && fileCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK) {
                if (data != null && data.getData() != null) results = new Uri[]{data.getData()};
                else if (data != null && data.getClipData() != null) {
                    int n = data.getClipData().getItemCount();
                    results = new Uri[n];
                    for (int i=0;i<n;i++) results[i] = data.getClipData().getItemAt(i).getUri();
                }
            }
            fileCallback.onReceiveValue(results);
            fileCallback = null;
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQ_AUDIO && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Microphone permission granted. Tap Record again.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override public void onBackPressed() {
        webView.evaluateJavascript("(window.__nativeGoBack ? window.__nativeGoBack() : false)", value -> {
            if ("false".equals(value) || value == null) superOnBackPressed();
        });
    }

    private void superOnBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else finish();
    }

    @Override protected void onDestroy() {
        cleanupRecorder();
        if (fileCallback != null) fileCallback.onReceiveValue(null);
        webView.destroy();
        super.onDestroy();
    }
}
