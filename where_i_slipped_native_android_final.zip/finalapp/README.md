# Where I Slipped - Native Android

Offline Android app with local written doubts, camera/gallery image selection, native voice recording, and Android Back navigation.

This build includes the saved-image thumbnail renderer fix.

Theme: Midnight Aurora - navy/violet palette, per-subject accent colours (Physics blue, Chemistry violet-pink, Zoology amber, Botany emerald) and a refreshed motion layer.
