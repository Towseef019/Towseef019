# Where I Slipped - Native Android

Offline Android app with local written doubts, camera/gallery image selection, native voice recording, and Android Back navigation.

This build includes the saved-image thumbnail renderer fix.
