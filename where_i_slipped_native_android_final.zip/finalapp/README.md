# Where I Slipped - Native Android

Offline Android app with local written doubts, camera/gallery image selection, native voice recording, and Android Back navigation.

This build includes the saved-image thumbnail renderer fix.

Theme: Midnight Aurora - navy/violet palette, per-subject accent colours (Physics blue, Chemistry violet-pink, Zoology amber, Botany emerald) and a refreshed motion layer.

## v2 feature layer
- Bottom nav: Add / Revise / Insights / Search (Android Back closes panels first)
- Revise: Leitner spaced repetition (1, 3, 7, 14, 30 day boxes), reveal-then-rate cards, due badge
- Insights: streak, 14-day chart, biggest-leak ring with coaching tip, subject split, weakest chapters, mastery %
- Search: full-text across all doubts (including text-only ones), subject filter, tap thumbnail to zoom
- Share weekly report via Android share sheet; light haptics

## v3 additions (from what NEET/JEE students ask for)
- Study tab: stopwatch (start, pause, resume, stop and log) by subject with studied-today/7-day totals, mock-score trend (scores capped at 720), tests and exams calendar (multiple named tests, countdown chip for the next one)
- Revise modes: Due today, Weekly retake (last 7 days, no schedule), Sprint (recurring-weak chapters only)
- "My rule" field on every revision card (preventive rule, shown again next time)
- Insights: weekly focus hours by subject
- Backup: export/restore notes + progress as text (photos and voice stay on the phone)

## Mistake types
Conceptual, Silly, Calculation, IQ question, Memory slip, Other (write your own). Edit the list in `MISTAKE_TYPES` in assets/index.html.

## Performance
Subject picker has no endless animations (blobs, headline shimmer, floating icons, pulsing ring, button shine). Background loops pause while it is open. Google Fonts no longer blocks first paint. Edit the `perf-lite` block at the end of assets/index.html to bring any effect back.
