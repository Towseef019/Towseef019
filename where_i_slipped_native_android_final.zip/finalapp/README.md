# Where I Slipped - Native Android

Offline Android build of Where I Slipped. The HTML app is bundled locally. Native Android code provides microphone recording and Android Back navigation, while the app keeps its IndexedDB local storage.

Build: `gradle :app:assembleDebug`
